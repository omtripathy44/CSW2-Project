package com.perfume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfumeApplication {
    public static void main(String[] args) {
        SpringApplication.run(PerfumeApplication.class, args);
    }
}
