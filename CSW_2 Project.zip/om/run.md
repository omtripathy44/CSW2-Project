To run
properly setup java sdk , mvn

cd into backend run
$ mvn spring-boot:run

# Frontend
open index.html in browser or through nodemon